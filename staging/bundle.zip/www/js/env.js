window.APP_MODE = 'empleado';
